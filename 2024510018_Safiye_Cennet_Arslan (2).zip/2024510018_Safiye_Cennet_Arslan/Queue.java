
public class Queue {
	private Object[] elements;
    private int front, rear, count;
    
    public Queue(int capacity) {
        elements = new Object[capacity];
        front = 0;
        rear = -1;
        count = 0; //o an queuedaki eleman sayısını tutar
    }
    
    public void enqueue(Object data) {
        if (!isFull()) {
            rear = (rear + 1) % elements.length;
            elements[rear] = data;
            count++;
        }
    }
    
    public Object dequeue() {
        if (!isEmpty()) {
            Object data = elements[front];
            front = (front + 1) % elements.length;
            count--;
            return data;
        }
        return null;
    }
    
    public Object peek() {
        if (!isEmpty()) 
        	return elements[front];
        return null;
    }
    
    public boolean isEmpty() { 
    	return count == 0; 
    	}
    
    public boolean isFull() { 
    	return count == elements.length; 
    	}
    
    public int size() { 
    	return count; 
    	}
}
