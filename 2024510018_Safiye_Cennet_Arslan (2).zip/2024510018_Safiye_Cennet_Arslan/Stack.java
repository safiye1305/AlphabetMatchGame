
public class Stack {
	private char[] elements;
    private int top;
    
    public Stack(int capacity) {
        elements = new char[capacity];
        top = -1;
    }
    
    public void push(char data) {
        if (!isFull()) 
        	elements[++top] = data;
    }
    
    public char pop() {
        if (!isEmpty()) 
        	return elements[top--];
        return ' ';
    }
    
    public char peek() {
        if (!isEmpty()) 
        	return elements[top];
        return ' ';
    }
    
    public boolean isEmpty() { 
    	return top == -1; 
    	}
    
    public boolean isFull() { 
    	return top+1 == elements.length; 
    	}
    
    public int size() { 
    	return top + 1; 
    	}
}
