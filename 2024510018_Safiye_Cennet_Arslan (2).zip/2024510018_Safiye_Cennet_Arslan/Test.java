import java.util.*;
import java.io.*;
public class Test {
	static Stack[] sets = new Stack[5];
    static Queue reserveQueue = new Queue(26);
    static Queue supplementaryQueue = new Queue(26);
    static int score = 0;
    static int steps = 0;
    static int shiftRights;
    static int maxSteps = 0;
    
    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(System.in);
        Random rnd = new Random();
        System.out.print("Enter player name: ");
        String playerName = scan.nextLine();
        initializeGame(rnd);
        System.out.println("\nTHE GAME STARTS NOW");
        while (true) {
            displayState();          
            if (isAllEmpty() || steps >= maxSteps) {
                String reason;               
                if (isAllEmpty()) {
                    reason = "ALL SETS EMPTY"; 
                } else {
                    reason = "MAX STEPS REACHED"; 
                }
                System.out.println("\n" + reason + "GAME OVER");
                break; 
            }
            System.out.print(">> ");
            String command = scan.nextLine();
            if (command.equalsIgnoreCase("F")) 
            	break;
            if (processCommand(command)) {
                steps++;
                if (steps > 0 && steps % 3 == 0) 
                	autoAdd();
            }
        }
        System.out.println("\nEND OF THE GAME");
        updateHighScore(playerName, score);
        scan.close();
    }
    
    static void initializeGame(Random rnd) {
        int totalInitial = 0;
        char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();  
        for (int i = 0; i < 5; i++) {
            sets[i] = new Stack(10);
            int count = rnd.nextInt(10) + 1;
            for (int j = 0; j < count; j++) {
                sets[i].push(alphabet[rnd.nextInt(26)]);
            }
            totalInitial += sets[i].size();
        }
        maxSteps = (int) (totalInitial * 1.2);
        shiftRights = rnd.nextInt(5) + 1;
        shuffleAndFillQueue(reserveQueue, alphabet, rnd);
        shuffleAndFillQueue(supplementaryQueue, alphabet, rnd);
    }
    
    static void shuffleAndFillQueue(Queue q, char[] arr, Random rnd) {
    	char[] temp = new char[arr.length]; 
    	for (int i = 0; i < arr.length; i++) { 
    	    temp[i] = arr[i]; 
    	}
        for (int i = temp.length - 1; i > 0; i--) {
            int j = rnd.nextInt(i + 1);
            char a = temp[i]; 
            temp[i] = temp[j]; 
            temp[j] = a;
        }
        for (int i = 0; i < temp.length; i++) {
            q.enqueue(temp[i]); 
        }
    }
    
    static boolean processCommand(String command) {
        if (command.startsWith("Match")) {           
            if (command.contains("(") && command.contains(",") && command.contains(")")) {                     
                int openParen = command.indexOf("(");
                int comma = command.indexOf(",");
                int closeParen = command.indexOf(")"); 
                String strI = command.substring(openParen + 1, comma).trim();
                String strJ = command.substring(comma + 1, closeParen).trim(); 
                int i = Integer.parseInt(strI) - 1;
                int j = Integer.parseInt(strJ) - 1;
                if (i >= 0 && i < 5 && j >= 0 && j < 5) {
                    if (sets[i].isEmpty() || sets[j].isEmpty()) {
                        System.out.println("Warning: One of the sets is empty");
                    } else if (sets[i].peek() == sets[j].peek()) {
                        sets[i].pop(); 
                        sets[j].pop();
                        score += 5;
                        System.out.println("Match successful! +5 points");
                    } else {
                        System.out.println("Warning:Tiles don't match");
                    }
                    return true; 
                }
            }
            System.out.println("Invalid Match format,Use Match(i,j)");
        } 
        else if (command.startsWith("AddSet")) {
            if (command.contains("(") && command.contains(")")) {
                int openParen = command.indexOf("(");
                int closeParen = command.indexOf(")");               
                String strI = command.substring(openParen + 1, closeParen).trim();
                int i = Integer.parseInt(strI) - 1;
                if (i >= 0 && i < 5) {
                    if (shiftRights <= 0) {
                        score -= 2;
                        System.out.println("No shift rights left. AddSet penalty: -2 points.");
                    }
                    char tile = (char) reserveQueue.dequeue();
                    if (sets[i].isFull()) {
                        System.out.println("Warning:Set full,Tile returned to queue");
                        reserveQueue.enqueue(tile);
                    } else {
                        sets[i].push(tile);
                    }
                    return true; 
                }
            }
            System.out.println("Invalid AddSet format,Use AddSet(i)");
        }
        else if (command.equalsIgnoreCase("ShiftQueue")) {
            if (shiftRights > 0) {
                reserveQueue.enqueue(reserveQueue.dequeue());
                shiftRights--;
                System.out.println("Reserve queue shifted.");
                return true;
            } else {
                System.out.println("Warning: No shift rights left!");
                return false;
            }
        }

        return false; 
    }
    
    static void autoAdd() {
        int minIdx = 0;
        for (int i = 1; i < 5; i++) {
            if (sets[i].size() < sets[minIdx].size()) 
            	minIdx = i;
        }
        char tile = (char) supplementaryQueue.dequeue();
        if (sets[minIdx].isFull()) supplementaryQueue.enqueue(tile);
        else {
            sets[minIdx].push(tile);
            System.out.println("[Auto] Tile added to Set" + (minIdx + 1));
        }
    }
    
    static void displayState() {
        System.out.println("\nScore: " + score + " | Remaining Shifts: " + shiftRights + " | Step: " + steps + "/" + maxSteps);
        for (int i = 0; i < 5; i++) {
            System.out.print("Set" + (i + 1) + ": Top -> ");
            displayStack(sets[i]);
        }
        System.out.print("Reserve Queue: Front -> "); displayQueue(reserveQueue);
        System.out.print("Supplementary Queue: Front -> "); displayQueue(supplementaryQueue);
    }
    
    static void displayStack(Stack s) {
        Stack temp = new Stack(10); //geçici stack
        while (!s.isEmpty()) {
            char c = s.pop();
            System.out.print(c + " ");
            temp.push(c);
        }
        while (!temp.isEmpty()) 
        	s.push(temp.pop());
        System.out.println("<- Bottom");
    }
    
    static void displayQueue(Queue q) {
        int size = q.size();
        for (int i = 0; i < size; i++) {
            Object data = q.dequeue();
            System.out.print(data + " ");
            q.enqueue(data);
        }
        System.out.println("<- Rear");
    }
    
    static boolean isAllEmpty() {
        for (int i = 0; i < 5; i++) {           
            if (sets[i].isEmpty() == false) {
                return false; 
            }
        }
        return true; 
    }
    
    static void updateHighScore(String name, int score) throws IOException {
        Queue table = new Queue(10);  
        File f = new File("HighScoreTable.txt");
        if (f.exists()) {
            Scanner fs = new Scanner(f);
            while (fs.hasNext() && !table.isFull()) {
                String pName = fs.next();
                int pScore = fs.nextInt();
                table.enqueue(pName + " " + pScore);
            }
            fs.close();
        }
        Queue newTable = new Queue(10);
        boolean added = false;
        int originalSize = table.size();
        for (int i = 0; i < originalSize; i++) {
            String entry = (String) table.dequeue();
            String[] parts = entry.split(" ");
            int existingScore = Integer.parseInt(parts[1]);
            if (!added && score >= existingScore) {
                if (!newTable.isFull()) {
                    newTable.enqueue(name + " " + score);
                }
                added = true;
            }
            if (!newTable.isFull()) {
                newTable.enqueue(entry);
            }
        }
        if (!added && !newTable.isFull()) {
            newTable.enqueue(name + " " + score);
        }
        PrintWriter pw = new PrintWriter(new FileWriter("HighScoreTable.txt"));
        System.out.println("\n--- High Score Table ---");   
        while (!newTable.isEmpty()) {
            String row = (String) newTable.dequeue();
            System.out.println(row);
            pw.println(row); 
        }
        pw.close();
        
    }
}
